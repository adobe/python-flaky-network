
import flakynetworksimulator.flakynetwork as f

fn = f.FlakyNetwork(p="4g")

fn.dropoutSim(dropout=0.2,tout=120)