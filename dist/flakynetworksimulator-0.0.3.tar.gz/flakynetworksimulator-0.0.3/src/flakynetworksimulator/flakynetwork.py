"""
Created by Gauransh Soni on 27th June
Simulation of Variable real life bandwidth situation

"""
# imports
import random
import subprocess
from time import sleep
import os
from constants import *



# profiles
profiles = {
    "3g":[768,1600,150,0],
    "3gfast":[768,1600,75,0],
    "3gslow":[400,400,200,0],
    "2g":[256,280,400,0],
    "cable":[1000,5000,14,0],
    "dsl":[384,1500,14,0],
    "4g":[9000,9000,85,0],
    "lte":[12000,12000,35,0],
    "edge":[200,240,35,0],    
    "stop":[0,0,1000,0]
}
# class flakynetwork
class FlakyNetwork:
    def __init__(self, dns=TEST_DNS, p = MOBILE_DATA, ping_count = PING_COUNT):
        self.dns  = dns
        self.p = p
        self.dropout = profiles.get(p)[3]
        self.upspeed = profiles.get(p)[0]
        self.downspeed = profiles.get(p)[1]
        self.dropout = DROPOUT
        self.ping = profiles.get(p)[2]
        self.ping_count = ping_count
        self.cwd = os.path.dirname(os.path.realpath(__file__))

    def __flushThrottler(self):
        try:
            cwd = self.cwd
            with open(cwd + '/py_subprocess_out.log',"a") as outfile:

                subprocess.run(["pfctl" ,"-f" ,"/etc/pf.conf"],stdout=outfile, stderr=subprocess.STDOUT)
                subprocess.run(["dnctl", "-q", "flush"],stdout=outfile, stderr=subprocess.STDOUT)
        except:
            print("Error in flushing")
    
    def createProfile(self,name,up,down,ping,dropout):
        profiles[name] = [up,down,ping,dropout]


    def __pingDns(self):
        try:
            cwd = self.cwd
            with open(cwd + '/py_subprocess_out.log',"a") as outfile:
                print("This function is working")
                subprocess.run(["ping", "{dns}".format(dns= self.dns), "-c", "{c}".format(c=self.ping_count)],stdout=outfile, stderr=subprocess.STDOUT)
        except:
            print("Error Pinging")

    def __pipeConfig(self,pipe,speed,ping,dropout):
        try:
            return "dnctl pipe {pipe} config bw {speed}Kbits/s delay {ping}ms plr {dropout}".format(speed=speed, pipe = pipe,ping = ping,dropout = dropout)
        except:
            print("Error config the pipe")
    def __throttle(self):
        try:
            cwd = self.cwd
            up = self.upspeed
            down = self.downspeed
            ping = self.ping
            dropout = self.dropout
            with open(cwd +'/py_subprocess_out.log',"a") as outfile:
                subprocess.run(self.__pipeConfig(1,up,ping,dropout),shell=True,stdout=outfile,stderr=subprocess.STDOUT)
                subprocess.run(self.__pipeConfig(2,down,ping,dropout),shell=True,stdout=outfile,stderr=subprocess.STDOUT)
                subprocess.run("echo \"dummynet in from any to ! 127.0.0.1 pipe 1 \ndummynet out from !127.0.0.1 to any pipe 2\" | sudo pfctl -f -",shell=True,stdout=outfile, stderr=subprocess.STDOUT)
                subprocess.run("pfctl -E",shell=True,stdout=outfile, stderr=subprocess.STDOUT)
        except:
            print("Error check logs for more details")
    def __switch(self, wifi_profile, switches , timer, debug):
        try:
            cwd = self.cwd
            up = self.upspeed
            down = self.downspeed
            ping = self.ping
            dropout = self.dropout
            up_wifi = profiles.get(wifi_profile)[0]
            ping_wifi = profiles.get(wifi_profile)[1]
            dropout_wifi = profiles.get(wifi_profile)[3]
            down_wifi = profiles.get(wifi_profile)[2]
            with open(cwd +'/py_subprocess_out.log',"a") as outfile:
                subprocess.run("dnctl pipe 1 config delay 0ms noerror",shell=True,stdout=outfile, stderr=subprocess.STDOUT)
                subprocess.run("dnctl pipe 2 config delay 0ms noerror",shell=True,stdout=outfile, stderr=subprocess.STDOUT)
                subprocess.run("echo \"dummynet in from any to ! 127.0.0.1 pipe 1 \ndummynet out from !127.0.0.1 to any pipe 2\" | sudo pfctl -f -",shell=True,stdout=outfile, stderr=subprocess.STDOUT)
                # profile 1
                subprocess.run(self.__pipeConfig(1,up,ping,dropout),shell=True,stdout=outfile,stderr=subprocess.STDOUT)
                subprocess.run(self.__pipeConfig(2,down,ping,dropout),shell=True,stdout=outfile,stderr=subprocess.STDOUT)
                subprocess.run("pfctl -E",shell=True,stdout=outfile, stderr=subprocess.STDOUT)
                # switch starts-
                for i in range(switches):
                    # Switching to wifi
                    subprocess.run(self.__pipeConfig(1,up_wifi,ping_wifi,dropout_wifi),shell=True,stdout=outfile,stderr=subprocess.STDOUT)
                    subprocess.run(self.__pipeConfig(2,down_wifi,ping_wifi,dropout_wifi),shell=True,stdout=outfile,stderr=subprocess.STDOUT)
                    sleep(timer)
                    # Switching to mobile data
                    subprocess.run(self.__pipeConfig(1,up,ping,dropout),shell=True,stdout=outfile,stderr=subprocess.STDOUT)
                    subprocess.run(self.__pipeConfig(2,down,ping,dropout),shell=True,stdout=outfile,stderr=subprocess.STDOUT)
                    sleep(timer)
        except:
            print("Error check logs for more details")
    def __variableBandwidth(self, var):
        
        try:
            cwd = self.cwd
            up = self.upspeed
            low_up = up - round(up * var)
            high_up = up + round(up*var)
            ping = self.ping
            dropout = self.dropout
            with open(cwd +'/py_subprocess_out.log',"a") as outfile:
                # subprocess.run(["dnctl" ,"pipe", "1", "config", "bw", "{up}Kbit/s".format(up=up), "delay" , "{ping}".format(ping=ping), "plr", "{dropout}".format(dropout=dropout), "noerror"], stdout=outfile,stderr=subprocess.STDOUT) 
                # subprocess.run(" echo 'dummynet in proto {tcp,icmp} from" + " {dns} to any pipe 1' | sudo pfctl -f -".format(dns=self.dns), shell=True,stdout=outfile, stderr=subprocess.STDOUT)
                # subprocess.run(["pfctl", "-e"], stdout=outfile,stderr=subprocess.STDOUT)
                # sleep(4)
                subprocess.run("dnctl pipe 1 config delay 0ms noerror",shell=True)
                subprocess.run(" echo 'dummynet in proto {tcp,icmp} from" + " {dns} to any pipe 1' | sudo pfctl -f -".format(dns=self.dns), shell=True,stdout=outfile, stderr=subprocess.STDOUT)
                subprocess.run(["pfctl", "-e"], stdout=outfile,stderr=subprocess.STDOUT)
                for i in range(5):
                    bw = random.randint(low_up,high_up)
                    subprocess.run(self.__pipeConfig(1,bw,ping,dropout),shell=True,stdout=outfile,stderr=subprocess.STDOUT)
                    sleep(2)
        except:
            print("Error check logs for more details")
    def __throttleTest(self):
        try:
            cwd = self.cwd
            up = self.upspeed
            ping = self.ping
            dropout = self.dropout
            with open(cwd +'/py_subprocess_out.log',"a") as outfile:
                subprocess.run(self.__pipeConfig(1,up,ping,dropout),shell=True,stdout=outfile,stderr=subprocess.STDOUT)
                subprocess.run(" echo 'dummynet in proto {tcp,icmp} from" + " {dns} to any pipe 1' | sudo pfctl -f -".format(dns=self.dns), shell=True,stdout=outfile, stderr=subprocess.STDOUT)
                subprocess.run(["pfctl", "-e"], stdout=outfile,stderr=subprocess.STDOUT)
        except:
            print("Error check logs for more details")
    def __switchTest(self, wifi_profile, switches , timer, debug = False):
        try:
            cwd = self.cwd
            up = self.upspeed
            ping = self.ping
            dropout = self.dropout
            # Wifi profile
            up_wifi = profiles.get(wifi_profile)[0]
            ping_wifi = profiles.get(wifi_profile)[1]
            dropout_wifi = profiles.get(wifi_profile)[3]

            with open(cwd +'/py_subprocess_out.log',"a") as outfile:
                subprocess.run(["dnctl" ,"pipe", "1", "config", "bw", "{up}Kbit/s".format(up=up), "delay" , "{ping}".format(ping=ping), "plr", "{dropout}".format(dropout=dropout), "noerror"], stdout=outfile,stderr=subprocess.STDOUT) 
                subprocess.run(" echo 'dummynet in proto {tcp,icmp} from" + " {dns} to any pipe 1' | sudo pfctl -f -".format(dns=self.dns), shell=True,stdout=outfile, stderr=subprocess.STDOUT)
                subprocess.run(["pfctl", "-e"], stdout=outfile,stderr=subprocess.STDOUT)
                # start switching
                for i in range(switches):
                    print("wifi")
                    subprocess.run(self.__pipeConfig(1,up_wifi,ping_wifi,dropout_wifi),shell=True,stdout=outfile,stderr=subprocess.STDOUT)
                    sleep(timer)
                    print("mobile data")
                    subprocess.run(self.__pipeConfig(1,up,ping,dropout),shell=True,stdout=outfile,stderr=subprocess.STDOUT)
                    sleep(timer)    
        except:
            print("Error! Please check logs for more details")
    def __variableBandwitdhTest(self, var = .1):
        try:
            cwd = self.cwd
            up = self.upspeed
            low_up = up - round(up * var)
            high_up = up + round(up*var)
            ping = self.ping
            dropout = self.dropout
            with open(cwd +'/py_subprocess_out.log',"a") as outfile:
                # subprocess.run(["dnctl" ,"pipe", "1", "config", "bw", "{up}Kbit/s".format(up=up), "delay" , "{ping}".format(ping=ping), "plr", "{dropout}".format(dropout=dropout), "noerror"], stdout=outfile,stderr=subprocess.STDOUT) 
                # subprocess.run(" echo 'dummynet in proto {tcp,icmp} from" + " {dns} to any pipe 1' | sudo pfctl -f -".format(dns=self.dns), shell=True,stdout=outfile, stderr=subprocess.STDOUT)
                # subprocess.run(["pfctl", "-e"], stdout=outfile,stderr=subprocess.STDOUT)
                # sleep(4)
                subprocess.run("dnctl pipe 1 config delay 0ms noerror",shell=True)
                subprocess.run(" echo 'dummynet in proto {tcp,icmp} from" + " {dns} to any pipe 1' | sudo pfctl -f -".format(dns=self.dns), shell=True,stdout=outfile, stderr=subprocess.STDOUT)
                subprocess.run(["pfctl", "-e"], stdout=outfile,stderr=subprocess.STDOUT)
                for i in range(5):
                    bw = random.randint(low_up,high_up)
                    subprocess.run(self.__pipeConfig(1,bw,ping,dropout),shell=True,stdout=outfile,stderr=subprocess.STDOUT)
                    sleep(2)
        except:
            print("Error check logs for more details")
    def stop(self):
        self.__flushThrottler()
    def pingg(self):
        self.__pingDns()
    def start(self, mode=DEFAULT_MODE,wifi_profile=WIFI_PROFILE, switches = SWITCHES, timer = TIMER, debug = DEBUG_MODE,bw_var = BANDWIDTH_VAR):
        if(mode==0):
            self.__throttle()
        elif(mode==1):
            self.__variableBandwidth(var=bw_var)
        elif(mode==2):
            self.__switch(switches=switches,timer=timer,wifi_profile=wifi_profile)
        else:
            print("Mode can only be 0,1 or 2")
    
    def test(self, mode=DEFAULT_MODE,wifi_profile=WIFI_PROFILE, switches = SWITCHES, timer = TIMER, debug = DEBUG_MODE, bw_var = BANDWIDTH_VAR):
        if(mode==0):
            self.__throttleTest()
        elif(mode==1):
            self.__variableBandwitdhTest(var=bw_var)
        elif(mode==2):
            self.__switchTest(switches=switches,timer=timer,wifi_profile=wifi_profile)
        else:
            print("Mode can only be 0,1 or 2")



