# flakynetwork
First Version supported only on macOS


Install using 
python3 -m pip install --index-url https://test.pypi.org/simple/ --no-deps flakynetworksimulator